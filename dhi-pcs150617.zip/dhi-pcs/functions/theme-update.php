<?php

omfw_Framework::theme_update(get_option('eventerra_envato_username'), get_option('eventerra_envato_api'));