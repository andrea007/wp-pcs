<?php

require_once (EVENTERRA_TEMPLATE_DIR . '/functions/theme-options-fields.php'); // eventerra_get_theme_options function inside

omfw_Framework::theme_options('eventerra_get_theme_options');

	
