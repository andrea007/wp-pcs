<div <?php post_class('blog-single'); ?> id="post-<?php the_ID(); ?>">
