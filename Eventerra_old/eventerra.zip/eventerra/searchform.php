<form role="search" method="get" id="searchform" action="<?php echo esc_url( home_url('/') ); ?>/">
	<input type="text" name="s" class="searchform-s" placeholder="<?php esc_html_e('Type and press enter to search', 'eventerra') ?>" />
</form>