	<?php get_template_part( 'includes/post-meta'); ?>
	
	<div class="post-content post-content-full entry-content">
		<?php the_content(); ?>
	</div>
</div>