<?php

/**
 * Plugin Name: Olevmedia Persons
 * Plugin URI: http://olevmedia.com/
 * Description: Addon to Olevmedia Themes, which come with WPBakery Visual Composer plugin. Adds Persons functionality.
 * Version: 1.0.1
 * Author: Olevmedia
 * Author URI: http://olevmedia.com/
 */

$plugin_dir_url=plugin_dir_url( __FILE__ );

$GLOBALS['omPersonsPlugin'] = array(
	'version' => '1.0.1',
	'path' => plugin_dir_path( __FILE__ ),
	'path_url' => $plugin_dir_url,
	'plugin_basename' => plugin_basename( __FILE__ ),
	'config' => array(
		'include_front_css' => true,
		'update_api_url' => 'http://update-api.olevmedia.net/',
		'post_slug' => 'persons',
		'post_type_labels' => array(
			'name' => __( 'Persons','om_persons'),
			'singular_name' => __( 'Person','om_persons' ),
			'add_new' => __('Add New','om_persons'),
			'add_new_item' => __('Add New Person','om_persons'),
			'edit_item' => __('Edit Person','om_persons'),
			'new_item' => __('New Person','om_persons'),
			'view_item' => __('View Person','om_persons'),
			'search_items' => __('Search Persons','om_persons'),
			'not_found' =>  __('No persons found','om_persons'),
			'not_found_in_trash' => __('No persons found in Trash','om_persons'), 
			'parent_item_colon' => '',
		),
		'post_taxonomies_labels' => array(
			'name' => __( 'Persons Categories', 'om_persons' ),
			'singular_name' => __( 'Persons Category', 'om_persons' ),
			'search_items' =>  __( 'Search Persons Categories', 'om_persons' ),
			'popular_items' => __( 'Popular Persons Categories', 'om_persons' ),
			'all_items' => __( 'All Persons Categories', 'om_persons' ),
			'parent_item' => __( 'Parent Persons Category', 'om_persons' ),
			'parent_item_colon' => __( 'Parent Persons Category:', 'om_persons' ),
			'edit_item' => __( 'Edit Persons Category', 'om_persons' ), 
			'update_item' => __( 'Update Persons Category', 'om_persons' ),
			'add_new_item' => __( 'Add New Persons Category', 'om_persons' ),
			'new_item_name' => __( 'New Persons Category Name', 'om_persons' ),
			'separate_items_with_commas' => __( 'Separate persons categories with commas', 'om_persons' ),
			'add_or_remove_items' => __( 'Add or remove persons categories', 'om_persons' ),
			'choose_from_most_used' => __( 'Choose from the most used persons categories', 'om_persons' ),
			'menu_name' => __( 'Persons Categories', 'om_persons' ),
		),
		'post_extra_labels' => array(
			'sort' => __('Sort Persons','om_persons'),
			'sort_full' => __('Sort Persons by drag-n-drop. Items at the top will appear first.','om_persons'),
			'details' => __('Person Details', 'om_persons'),
		),
	),
);


function ompn_get_config_from_theme() {
	$GLOBALS['omPersonsPlugin']['config'] = apply_filters('ompn_config', $GLOBALS['omPersonsPlugin']['config']);
}
add_action('init', 'ompn_get_config_from_theme');


load_plugin_textdomain( 'om_persons', false, $GLOBALS['omPersonsPlugin']['path'] . 'languages/' );

add_theme_support( 'post-thumbnails', array( 'om-persons' ) );

include_once( 'functions/plugin-update.php' );
include_once( 'functions/custom-post.php' );
include_once( 'functions/custom-post-meta.php' );
