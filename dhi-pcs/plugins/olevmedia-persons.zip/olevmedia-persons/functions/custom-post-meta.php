<?php

/*************************************************************************************
 *	Add MetaBox to Testimonials edit page
 *************************************************************************************/

function ompn_add_persons_meta_box() {
	
	$metabox=array (
		'id' => 'ompn-persons-meta-box-details',
		'name' =>  $GLOBALS['omPersonsPlugin']['config']['post_extra_labels']['details'],
		'fields' => array (
			array ( "name" => __('Post / profession / short description','om_persons'),
					"desc" => '',
					"id" => "om_persons_post",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Email','om_persons'),
					"desc" => '',
					"id" => "om_persons_email",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Web site','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_site",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Behance link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_behance",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Dribbble link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_dribbble",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Facebook link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_facebook",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Flickr link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_flickr",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('GitHub link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_github",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Google+ link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_google",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Instagram link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_instagram",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('LinkedIn link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_linkedin",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Skype link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_skype",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Twitter link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_twitter",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('Vimeo link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_vimeo",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('VK link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_vk",
					"type" => "text",
					"std" => '',
			),
			array ( "name" => __('YouTube link','om_persons'),
					"desc" => '',
					"id" => "om_persons_link_youtube",
					"type" => "text",
					"std" => '',
			),
		),
	);
	
	$metabox=apply_filters('ompn_persons_meta_box', $metabox);

	add_meta_box(
		$metabox['id'],
		$metabox['name'],
		'ompn_persons_meta_box_html',
		'om-persons',
		( isset($metabox['context']) ? $metabox['context'] : 'normal' ),
		( isset($metabox['priority']) ? $metabox['priority'] : 'high' ),
		$metabox
	);
	
}
add_action('add_meta_boxes', 'ompn_add_persons_meta_box');

/*************************************************************************************
 *	Display MetaBox data
 *************************************************************************************/
 
function ompn_persons_meta_box_html($post, $metabox) {
	
	$fields=$metabox['args']['fields'];

	$output='';
	
	$output.= '<input type="hidden" name="ompn_meta_box_nonce" value="'.wp_create_nonce(basename(__FILE__)).'" />';

	$output.= '<table class="form-table"><col width="25%"/><col/>';
 
	foreach ($fields as $field) {
		
		$meta = get_post_meta($post->ID, $field['id'], true);
		
		if(has_filter('ompn_persons_meta_box_html_'.$field['type'])) {
			$output.=apply_filters('ompn_persons_meta_box_html_'.$field['type'], $field);
		} else {
		
			switch ($field['type']) {
	
				case 'text':
					$output.= '
						<tr>
							<th>
								<label for="'.$field['id'].'"><strong>'.$field['name'].'</strong>
								<div class="howto">'. $field['desc'].'</div>
							</th>
							<td>
								<input type="text" name="'.$field['id'].'" id="'.$field['id'].'" value="'.esc_attr( ($meta ? $meta : $field['std']) ). '" style="width:75%;" />
							</td>
						</tr>
					';
				break;
				
			}
			
		}

	}
	$output.= '</table>';
	
	echo $output;
}

/*************************************************************************************
 *	Save MetaBox data
 *************************************************************************************/

function ompn_save_persons_metabox($post_id) {

 	if (!isset($_POST['ompn_meta_box_nonce']) || !wp_verify_nonce($_POST['ompn_meta_box_nonce'], basename(__FILE__))) {
		return $post_id;
	}
		
	// check autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return $post_id;
	}
 
	// check permissions
	if (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}

	$fields=ompn_persons_contact_icons();

	$fields[]='om_persons_post';

	foreach($fields as $v) {
		if( isset($_POST[$v]) ) {
			update_post_meta($post_id, $v, $_POST[$v]);
		}
	}

	do_action('ompn_save_persons_metabox',$_POST);
	
}
add_action('save_post', 'ompn_save_persons_metabox');

/*************************************************************************************
 *	Persons Contact Icons
 *************************************************************************************/
 
function ompn_persons_contact_icons() {
	return apply_filters( 'ompn_persons_contact_icons' , array(
		'envelope'=>'om_persons_email',
		'site'=>'om_persons_link_site',
		'behance'=>'om_persons_link_behance',
		'dribbble'=>'om_persons_link_dribbble',
		'facebook'=>'om_persons_link_facebook',
		'flickr'=>'om_persons_link_flickr',
		'github'=>'om_persons_link_github',
		'google-plus'=>'om_persons_link_google',
		'instagram'=>'om_persons_link_instagram',
		'linkedin'=>'om_persons_link_linkedin',
		'skype'=>'om_persons_link_skype',
		'twitter'=>'om_persons_link_twitter',
		'vimeo'=>'om_persons_link_vimeo',
		'vk'=>'om_persons_link_vk',
		'youtube'=>'om_persons_link_youtube',
	) );
}