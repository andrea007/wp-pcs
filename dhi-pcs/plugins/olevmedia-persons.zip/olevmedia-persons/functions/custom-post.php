<?php

/*************************************************************************************
 *	Add Persons Post Type
 *************************************************************************************/
 
function ompn_create_persons() {	  
	register_post_type( 'om-persons', array(
		'labels' => $GLOBALS['omPersonsPlugin']['config']['post_type_labels'],
		'public' => true,
		'query_var' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'exclude_from_search' => false,
		'supports' => array('title','editor','thumbnail','custom-fields','page-attributes','excerpt'),
		'rewrite' => array('slug'=>$GLOBALS['omPersonsPlugin']['config']['post_slug']),
	));
	
}
add_action( 'init', 'ompn_create_persons' );

/*************************************************************************************
 *	Add Persons Types
 *************************************************************************************/
 
function ompn_add_persons_taxonomies(){
	
	$args=array (
		'hierarchical' => true,
		'labels' => $GLOBALS['omPersonsPlugin']['config']['post_taxonomies_labels'],
		'query_var' => true,
		'rewrite' => array('slug' => 'om-persons-type', 'hierarchical' => true)
	);
	
	register_taxonomy(
		'om-persons-type', 
		'om-persons', 
		$args
	);

}
add_action( 'init', 'ompn_add_persons_taxonomies' );

/*************************************************************************************
 *	Persons Sort Page
 *************************************************************************************/

function ompn_persons_sort_page_add() {
	add_submenu_page('edit.php?post_type=om-persons', $GLOBALS['omPersonsPlugin']['config']['post_extra_labels']['sort'], $GLOBALS['omPersonsPlugin']['config']['post_extra_labels']['sort'], 'edit_posts', 'persons_sort', 'ompn_persons_sort_page');
}
add_action('admin_menu', 'ompn_persons_sort_page_add');

function ompn_enqueue_scripts_persons_sort($hook) {
	if('om-persons_page_persons_sort' != $hook)
		return;

	wp_enqueue_style('nav-menu');

	wp_enqueue_script('jquery');
	wp_enqueue_script('jquery-ui-sortable');
	
	wp_enqueue_script('ompn-persons-sort', $GLOBALS['omPersonsPlugin']['path_url'].'assets/js/items-sort.js', array('jquery','jquery-ui-sortable'));
}
add_action('admin_enqueue_scripts', 'ompn_enqueue_scripts_persons_sort');

function ompn_persons_sort_page() {
	$query = new WP_Query('post_type=om-persons&posts_per_page=-1&orderby=menu_order&order=ASC');
	?>
	<div class="wrap">
		<div id="icon-edit-pages" class="icon32 icon32-posts-page"><br /></div>
		<h2><?php echo esc_html($GLOBALS['omPersonsPlugin']['config']['post_extra_labels']['sort']) ?></h2>
		<p><?php echo esc_html($GLOBALS['omPersonsPlugin']['config']['post_extra_labels']['sort_full']) ?></p>
	
		<ul id="ompn_persons_items">
			<?php while( $query->have_posts() ) : $query->the_post(); ?>
				<?php if( get_post_status() == 'publish' ) { ?>
					<li id="<?php the_id(); ?>" class="menu-item">
						<dl class="menu-item-bar">
							<dt class="menu-item-handle">
								<span class="menu-item-title"><?php the_title(); ?></span>
							</dt>
						</dl>
						<ul class="menu-item-transport"></ul>
					</li>
				<?php } ?>
			<?php endwhile; ?>
		</ul>
	</div>
	<script>
		jQuery(function($){
			ompn_items_sort('#ompn_persons_items','ompn_persons_apply_sort');
		});
	</script>
	<?php wp_reset_postdata(); ?>
	<?php
}

function ompn_persons_apply_sort() {
	global $wpdb;
	
	$order = explode(',', $_POST['order']);
	$counter = 0;
	
	foreach($order as $id) {
		$wpdb->update($wpdb->posts, array('menu_order' => $counter), array('ID' => $id));
		$counter++;
	}
	exit();
}
add_action('wp_ajax_ompn_persons_apply_sort', 'ompn_persons_apply_sort');